package com.hugo.VideoFlix

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class VideoFlixApplicationTests {

	@Test
	fun contextLoads() {
	}

}
