package com.hugo.VideoFlix

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class VideoFlixApplication

fun main(args: Array<String>) {
	runApplication<VideoFlixApplication>(*args)
}
